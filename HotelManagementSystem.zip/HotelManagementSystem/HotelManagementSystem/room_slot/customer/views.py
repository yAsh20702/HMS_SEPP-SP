from django.shortcuts import render,redirect
from login.models import Customer
import datetime

def dashboard(request):
  if request.session.get('username',None) and request.session.get('type',None)=='manager':
        return redirect('manager_dashboard')
  if request.session.get('username',None) and request.session.get('type',None)=='customer':
      username=request.session['username']
      data=Customer.objects.get(username=username)
      return render(request,"user_dash/index.html")
  else:
      return redirect("user_login")


