from django.contrib import admin
from login.models import Customer, RoomManager

# Register your models here.
admin.site.register(Customer)
admin.site.register(RoomManager)
