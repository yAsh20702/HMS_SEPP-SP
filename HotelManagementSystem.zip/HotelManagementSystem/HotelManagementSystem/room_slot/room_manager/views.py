from django.shortcuts import render,redirect
from login.models import RoomManager
from datetime import date
from django.contrib import messages
import datetime

def dashboard(request):
  if not request.session.get('username',None):
      return redirect('manager_login')
  if request.session.get('username',None) and request.session.get('type',None)=='customer':
        return redirect('user_dashboard')
  if request.session.get('username',None) and request.session.get('type',None)=='manager':
      username=request.session['username']
      data=RoomManager.objects.get(username=username)
      return render(request,"manager_dash/index.html")
  else:
      return redirect("manager_login")
